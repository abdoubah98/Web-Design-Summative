# Accessibility Evidence

Place Lighthouse screenshots here.

Suggested screenshots:

- Problem1.png: Missing/weak image alt text before fixing.
- Fix1.png: Image alt text corrected.
- Problem2.png: Low contrast or missing form labels before fixing.
- Fix2.png: Contrast improved or form labels added.

Two example improvements made:

1. Added descriptive alt text to product images.
2. Added visible form labels and error messages for the contact form.
